DevView presents a view of the Windows 2000 kernel-mode namespace
and allows you to drill down to view device and driver objects
and symbolic links.

To install DevView, unzip DevView.zip into a directory of your choice.
You'll unzip this file, DevView.exe, and DevView.sys (a kernel-mode
helper for DevView.exe).

DevView requires beta-2 or later of Windows 2000. It will tell you so
if you try to run it under an earlier version of NT. It will just
fail to start on Windows 9x.

DevView is supplied AS-IS, without warranties of any kind. Since it
includes a kernel-mode component, there is always the possiblity that
program bugs may damage your system.

Questions or comments? Visit http://www.oneysoft.com and send me an
e-mail.